from tkinter import *
import socket

class Client:
    def __init__(self):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = '127.0.0.1'
        self.port = 5000
        self.client_socket.connect((self.host, self.port))

        self.gui = ClientGUI(self)
        self.gui.mainloop()

    def send_guess(self):
        guess = int(self.gui.guess_entry.get())
        self.client_socket.send(str(guess).encode('utf-8'))
        response = self.client_socket.recv(1024).decode('utf-8')
        self.gui.display_response(response)

class ClientGUI(Tk):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.title("Client")
        self.geometry("400x200")

        self.guess_entry = Entry(self)
        self.guess_entry.pack()

        self.send_button = Button(self, text="Send", command=self.client.send_guess)
        self.send_button.pack()

        self.response_label = Label(self, text="")
        self.response_label.pack()

    def display_response(self, response):
        self.response_label.config(text=response)

# Create the client
client = Client()
