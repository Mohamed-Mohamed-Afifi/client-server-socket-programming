from tkinter import messagebox
from tkinter import *
import random
import socket
import threading

class Server:
    def __init__(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = '127.0.0.1'
        self.port = 5000
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(1)

        self.player1_conn = None
        self.player2_conn = None

        self.player1_score = 0
        self.player2_score = 0

        self.generate_random_number()

        self.gui = ServerGUI(self)
        self.gui.mainloop()

    def generate_random_number(self):
        self.random_number = random.randint(1, 100)

    def start_game(self):
        self.gui.start_game()

    def check_guess(self, guess, conn):
        if guess < self.random_number:
            message = "Your guess is too low. Try again!"
            conn.send(message.encode('utf-8'))
        elif guess > self.random_number:
            message = "Your guess is too high. Try again!"
            conn.send(message.encode('utf-8'))
        else:
            message = "Correct! You guessed the number."
            conn.send(message.encode('utf-8'))

            if conn == self.player1_conn:
                self.player1_score += 1
            else:
                self.player2_score += 1

            self.gui.update_scores(self.player1_score, self.player2_score)
            self.generate_random_number()

            if self.player1_score == 3 or self.player2_score == 3:
                self.gui.game_over()

    def accept_connections(self):
        while True:
            conn, addr = self.server_socket.accept()

            if not self.player1_conn:
                self.player1_conn = conn
                threading.Thread(target=self.handle_client, args=(conn,)).start()
            elif not self.player2_conn:
                self.player2_conn = conn
                threading.Thread(target=self.handle_client, args=(conn,)).start()
            else:
                message = "Game is full. Try again later."
                conn.send(message.encode('utf-8'))
                conn.close()

    def handle_client(self, conn):
        conn.send("Welcome to the game! Waiting for other player...".encode('utf-8'))

        while True:
            guess = int(conn.recv(1024).decode('utf-8'))
            self.check_guess(guess, conn)

class ServerGUI(Tk):
    def __init__(self, server):
        super().__init__()
        self.server = server
        self.title("Server")
        self.geometry("400x200")

        self.player1_score_label = Label(self, text="Player 1 Score: 0")
        self.player1_score_label.pack()

        self.player2_score_label = Label(self, text="Player 2 Score: 0")
        self.player2_score_label.pack()

        self.start_button = Button(self, text="Start Game", command=self.server.start_game)
        self.start_button.pack()

    def start_game(self):
        self.start_button.config(state=DISABLED)

    def update_scores(self, player1_score, player2_score):
        self.player1_score_label.config(text=f"Player 1 Score: {player1_score}")
        self.player2_score_label.config(text=f"Player 2 Score: {player2_score}")
def game_over(self):
    winner = "Player 1" if self.server.player1_score == 3 else "Player 2"
    messagebox.showinfo("Game Over", f"{winner} wins the game!")
    self.destroy()

# Create and start the server
server = Server()
