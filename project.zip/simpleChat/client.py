from socket import *
from tkinter import *
client_socket=socket(AF_INET,SOCK_STREAM)
host = '127.0.0.1'
port = 3201  # Replace with the server's port number
client_socket.connect((host, port))

while True:
    try:
        client_socket.send(input("Mohamed_client : ").encode('utf-8'))
        server_Msg=client_socket.recv(2048).decode('utf-8')
        print("Server : ",server_Msg)
    except error as e:
        print("Error sending message:", str(e))
        client_socket.close()

# wind=Tk()
# wind.title("Simple Chat")
# wind.geometry("400x400")
# lb1=Label(wind,text="Client")
# lb1.grid(row=0,column=0)
# entry = Entry(wind, width=30)
# entry.grid(row=1,column=0)
# def sendToserver():
#     client_socket.send(entry.get().encode('utf-8'),"from client")
#     entry.delete(0, END)
# send_btn=Button(wind,text="Send",command=sendToserver)
# send_btn.grid(row=1,column=1)
# wind.mainloop()

# from tkinter import *
# from socket import *
# from threading import Thread

# # Client code
# def send_message():
#     message = entry.get()
#     client_socket.send(message.encode('utf-8'))
#     entry.delete(0, END)

# def receive_message():
#     while True:
#         try:
#             server_msg = client_socket.recv(2048).decode('utf-8')
#             root.after(10, lambda: chat_box.insert(END, "Server: " + server_msg + "\n"))
#         except error as e:
#             print("Error receiving message:", str(e))
#             client_socket.close()
#             break

# def connect_to_server():
#     global client_socket
#     host = '127.0.0.1'
#     port = 3201  # Replace with the server's port number
#     client_socket = socket(AF_INET, SOCK_STREAM)
#     client_socket.connect((host, port))
#     receive_thread = Thread(target=receive_message)
#     receive_thread.start()

# def send_message_handler(event):
#     send_message()

# root = Tk()
# root.title("Simple Chat")
# root.geometry("400x400")

# chat_box = Text(root, width=50, height=20)
# chat_box.pack()

# entry = Entry(root, width=30)
# entry.pack()
# entry.bind('<Return>', send_message_handler)

# send_button = Button(root, text="Send", command=send_message)
# send_button.pack()

# connect_to_server()

# root.mainloop()