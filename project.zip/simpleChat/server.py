from socket import *

host = '127.0.0.1'
port = 3201  # Replace with the server's port number

server_Socket=socket(AF_INET,SOCK_STREAM)
server_Socket.bind((host,port))
server_Socket.listen(5)
client,client_Info=server_Socket.accept()
while True:
    try:
        print("client :",client_Info[0],"is connecting")
        recived_Msg=client.recv(2048).decode('utf-8')
        print(client_Info[0],":",recived_Msg)
        client.send(input('Server :').encode('utf-8'))
    except error as e:
        print("Error sending message:", str(e))
        server_Socket.close()


# from tkinter import *
# from socket import *
# from threading import Thread


# # Server code
# def handle_client(client_socket, client_info):
#     while True:
#         try:
#             client_msg = client_socket.recv(2048).decode('utf-8')
#             root.after(10, lambda: chat_box.insert(END, "Client " + client_info[0] + ": " + client_msg + "\n"))
#             server_msg = input("Server: ")
#             client_socket.send(server_msg.encode('utf-8'))
#         except error as e:
#             print("Error sending/receiving message:", str(e))
#             client_socket.close()
#             break

# def start_server():
#     host = '127.0.0.1'
#     port = 3201  # Replace with the server's port number
#     server_socket = socket(AF_INET, SOCK_STREAM)
#     server_socket.bind((host, port))
#     server_socket.listen(5)
#     print("Server is listening for connections...")
#     while True:
#         client_socket, client_info = server_socket.accept()
#         print("Client", client_info[0], "is connected")
#         client_thread = Thread(target=handle_client, args=(client_socket, client_info))
#         client_thread.start()

# root = Tk()
# root.title("Simple Chat")
# root.geometry("400x400")

# chat_box = Text(root, width=50, height=20)
# chat_box.pack()

# start_server()

# root.mainloop()

# chat_box = Text(root, width=50, height=20)
# chat_box.pack()

# start_server()

# root.mainloop()
