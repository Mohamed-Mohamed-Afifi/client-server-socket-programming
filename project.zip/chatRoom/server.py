from socket import *
import threading

host='127.0.0.1'
port=7000
clients = []
aliases = []
def broadcast(message): 
    for client in clients: 
        client.send(message)

server_socket =socket(AF_INET,SOCK_STREAM)
server_socket.bind((host,port))
server_socket.listen(5)
print("Server is Connecting......")
def recive_thread():
    while True:
        client_Msg=client.recv(2048).encode('utf-8')
        print("Client : ",client_Msg)
def handel_client(client):
    while True:
        client.send(input("Server : ").encode('utf-8'))
        handel_revice=threading.Thread(target=recive_thread,args=(client,))
        handel_revice.start()
        handel_revice.join()
while True:
    client,clientInfo=server_socket.accept()
    print(clientInfo[0],"is connect to server")
    client_thread=threading.Thread(target=handel_client,args=(client,))
    client_thread.start()
    client_thread.join()
server_socket.close()