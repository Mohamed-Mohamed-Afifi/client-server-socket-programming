from socket import *
import threading

host='127.0.0.1'
port =7000
client_socket=socket(AF_INET,SOCK_STREAM)
client_socket.connect((host,port))

def handel_send():
        client_socket.send(input("Client : ").encode('utf-8'))
while True:
    try:
        server_Msg=client_socket.recv(2048).decode('utf-8')
        print("Server : ",server_Msg)
        send_thread=threading.Thread(target=handel_send,args=(client_socket,))
        send_thread.start()
        send_thread.join()
    except error as e:
        print("the is error : ",e)
client_socket.close()